package prova2;

import java.time.LocalDate;
import java.util.Arrays;

public class Principal {
	
	public static void main (String[]args) {
		
		Dependente dep = new Dependente();
		
		dep.setNome("Matheus");
		dep.setFiliacao("Irmão");

		// ---------------------------------------

		Equipe equi = new Equipe();
		
		equi.setNome("Suporte");
		equi.setDescrisao("Responsável por toda a área de TI da empresa");
		
		// ---------------------------------------
		
		Funcionario fun = new Funcionario();
		
		fun.setMatricula(1234);
		fun.setNome("Karina");
		fun.setEmail("karina@gmail.com");
		fun.setSalario(2200);
		fun.setDependente(Arrays.asList(dep));
		fun.setEquipe(equi);
		
		// ---------------------------------------
		
		Projeto pro = new Projeto();
		
		pro.setCodigo(9800);
		pro.setDataInicioProjeto(LocalDate.of(2017, 8, 16)); 											
		pro.setDataEntrega(LocalDate.of(2017, 8, 31));  												

		// ---------------------------------------
		
		Departamento depart = new Departamento();
		
		depart.setSetor("Departamento de Tecnologia da Informação");
		depart.setNomeFantasia("TI");
		
		// ---------------------------------------
		
		equi.setDepartamento(depart);
		equi.setProjeto(Arrays.asList(pro));
		equi.setFuncionario(Arrays.asList(fun));
		
		// ---------------------------------------
		
		System.out.println(fun);
		
		
	}

}
