package prova2;

import java.util.List;

public class Equipe {
	
	private String nome;
	private String descrisao;
	
	private List<Funcionario> funcionario;
	private 	List<Projeto> projeto;
	private Departamento departamento;
	
	public Equipe() {}
	
	public String toString() {
		return "Nome = " + nome + "\nDescrisão = " + descrisao + "] \n\nDepartamento = " + departamento + "]\n\nProjeto = \n" + projeto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrisao() {
		return descrisao;
	}

	public void setDescrisao(String descrisao) {
		this.descrisao = descrisao;
	}

	public List<Funcionario> getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(List<Funcionario> funcionario) {
		this.funcionario = funcionario;
	}

	public List<Projeto> getProjeto() {
		return projeto;
	}

	public void setProjeto(List<Projeto> projeto) {
		this.projeto = projeto;
	}

	public Departamento getDepartamento() {
		return departamento;
	}

	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}
	
	public void alocaFuncionario(Funcionario funcionario, Projeto projeto) {
	
	}

}
