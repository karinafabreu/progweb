package prova2;

import java.util.List;

public class Funcionario {
	
	private int matricula;
	private String nome;
	private String email;
	private float salario;
	
	private List<Dependente> dependente;
	private Equipe equipe;

	public Funcionario() {}
	
	public String toString() {
		return "Funcionario \n[Matricula = " + matricula + "\nNome = " + nome + "\nEmail = " + email + "\nSalario = R$ " + salario
				+ "\n\nDependente = \n" + dependente
				+ "\n\nEquipe = \n[" + equipe + "]";
	}


	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public float getSalario() {
		return salario;
	}

	public void setSalario(float salario) {
		this.salario = salario;
	}
	
	public List<Dependente> getDependente(){
		return dependente;
	}
	public void setDependente(List<Dependente> dependente) {
		this.dependente = dependente;
	}

	public Equipe getEquipe() {
		return equipe;
	}

	public void setEquipe(Equipe equipe) {
		this.equipe = equipe;
	}

}
